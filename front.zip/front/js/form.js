function openForm() {
    document.getElementById("loginForm").style.display = "flex";
}

function closeForm() {
    document.getElementById("loginForm").style.display = "none";
}